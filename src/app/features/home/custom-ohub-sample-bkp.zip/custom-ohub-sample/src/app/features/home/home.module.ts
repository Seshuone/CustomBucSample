import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import { HomeRoutingModule } from './home-routing.module';

import { TranslateService } from '@ngx-translate/core';
import { TranslateLoader } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import {
  BucCommonClassesAllModuleClazz,
  BucMultiTranslateHttpLoader
} from '@buc/svc-angular';
import { IVHomeComponent } from './ivhome/ivhome.component';
import { OMSHomeComponent } from './omshome/omshome.component';
import { OrdersHomeComponent } from './ordershome/ordershome.component';
import { BrowserModule } from '@angular/platform-browser';
  
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
  
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
//import {MatProgressBar} from '@angular/material/progress-bar';

export class CustomOhubSampleHomeModuleBundles {
  static bundles: Array<any> = [{
    prefix: './assets/custom-ohub-sample/i18n/home/ivhome',
    suffix: '.json'
  },
  {
    prefix: './assets/custom-ohub-sample/i18n/home/omshome',
    suffix: '.json'
  }
  ,
  {
    prefix: './assets/custom-ohub-sample/i18n/home/ordershome',
    suffix: '.json'
  }];
}

export function customOhubSampleHomeModuleHttpLoaderFactory(http: HttpClient) {
  return new BucMultiTranslateHttpLoader(http, CustomOhubSampleHomeModuleBundles.bundles);
}
/*
  INFO:
  BUC recommends using the multi translate loader for i18n and the superclass for this and every other lazy loaded feature module created
  for proper functioning of the application.
*/
@NgModule({
  declarations: [
    IVHomeComponent,
    OMSHomeComponent,
    OrdersHomeComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    HttpClientModule,
    MatIconModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: customOhubSampleHomeModuleHttpLoaderFactory,
        deps: [HttpClient]
      },
      isolate: true
    }),
    HomeRoutingModule
  ],
  exports: [MatButtonModule,
    MatInputModule,
  MatIconModule],
  providers: [],
  entryComponents: [OMSHomeComponent]
})
export class HomeModule extends BucCommonClassesAllModuleClazz {
  constructor(translateService: TranslateService) {
    super(translateService);
  }
}
