import { Component, VERSION, Input } from '@angular/core';
import { HttpClientModule, HttpClient, HttpRequest, HttpResponse, HttpEventType} from '@angular/common/http';
import { FormGroup, Validators, FormBuilder} from "@angular/forms";
import { Subscription } from "rxjs";
/* import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatProgressBar} from '@angular/material/progress-bar'; */

@Component({
  selector: 'file-upload',
  templateUrl: './ordershome.component.html',
  styleUrls: ['./ordershome.component.scss']
})
export class OrdersHomeComponent {
  @Input()
    requiredFileType:string;

    fileName = '';
    uploadProgress:number;
    uploadSub: Subscription;
  
  constructor(
    private http: HttpClient
    
    ) {   }
    baseApiUrl = "https://file.io"
    
    onFileSelected(event) {
      const file:File = event.target.files[0];
    
      if (file) {
          this.fileName = file.name;
          const formData = new FormData();
          formData.append("thumbnail", file);

          const upload$ = this.http.post("/api/thumbnail-upload", formData, {
              reportProgress: true,
              observe: 'events'
          })
          /* .pipe(
              finalize(() => this.reset())
          ); */
          // Create form data
        
      // Store form name as "file" with file data
      //formData.append("file", file, file.name);
        
      // Make http post request over api
      // with formData as req
      //return this.http.post(this.baseApiUrl, formData)
        
          this.uploadSub = upload$.subscribe(event => {
            if (event.type == HttpEventType.UploadProgress) {
              this.uploadProgress = Math.round(100 * (event.loaded / event.total));
            }
          })
      }
  }

cancelUpload() {
  this.uploadSub.unsubscribe();
  this.reset();
}

reset() {
  this.uploadProgress = null;
  this.uploadSub = null;
}
    
}
